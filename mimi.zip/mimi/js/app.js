const appliances = [
  {name:'Refrigerator', power:0.5},
  {name:'Air Conditioner', power:1.5},
  {name:'Television', power:0.15},
  {name:'Standing Fan', power:0.08},
  {name:'Bulb', power:0.01},
  {name:'Microwave', power:1.2},
  {name:'Washing Machine', power:0.5},
  {name:'Electric Iron', power:1.0}
];

const body = document.getElementById('applianceBody');
const totalEl = document.getElementById('totalConsumption');
const meterFill = document.getElementById('meterFill');
const recommendationText = document.getElementById('recommendationText');
const recommendationDetail = document.getElementById('recommendationDetail');

function remarkFor(value){
  if(value < 5) return ['low','Low'];
  if(value < 10) return ['medium','Medium'];
  if(value <= 15) return ['high','High'];
  return ['too-high','Too high'];
}

function renderRows(){
  body.innerHTML = '';
  appliances.forEach((item,index)=>{
    const row = document.createElement('tr');
    row.innerHTML = `
      <td class="appliance-name">${item.name}</td>
      <td><input class="qty" type="number" min="0" step="1" value="${item.qty ?? 0}" data-index="${index}"></td>
      <td class="unit">${item.power.toFixed(2)} kW</td>
      <td class="consumption" id="cons-${index}">0.00 kW</td>
      <td><span class="badge low" id="remark-${index}">Low</span></td>
    `;
    body.appendChild(row);
  });
  body.querySelectorAll('.qty').forEach(input => input.addEventListener('input', calculate));
  calculate();
}

function calculate(){
  let total = 0;
  appliances.forEach((item,index)=>{
    const input = document.querySelector(`.qty[data-index="${index}"]`);
    const qty = Math.max(0, Number(input?.value || 0));
    item.qty = qty;
    const consumption = qty * item.power;
    total += consumption;
    const consEl = document.getElementById(`cons-${index}`);
    const remEl = document.getElementById(`remark-${index}`);
    if(consEl) consEl.textContent = `${consumption.toFixed(2)} kW`;
    if(remEl){
      const [cls,label] = remarkFor(consumption);
      remEl.className = `badge ${cls}`;
      remEl.textContent = label;
    }
  });

  totalEl.textContent = total.toFixed(2);
  meterFill.style.width = `${Math.min((total/15)*100,100)}%`;

  return total;
}

function recommend(){
  const total = calculate();
  let title, detail;
  if(total < 7.5){
    title = '7.5kW Generator';
    detail = 'Your estimated load is below 7.5kW.';
  }else if(total < 10){
    title = '10kW Generator';
    detail = 'Your estimated load is between 7.5kW and 10kW.';
  }else if(total < 15){
    title = '15kW Generator';
    detail = 'Your estimated load is between 10kW and 15kW.';
  }else{
    title = 'We do not sell';
    detail = 'Your estimated consumption is 15kW or higher.';
  }
  recommendationText.textContent = title;
  recommendationDetail.textContent = detail;
}

document.getElementById('recommendBtn').addEventListener('click', recommend);

document.getElementById('resetBtn').addEventListener('click', ()=>{
  appliances.forEach(a => a.qty = 0);
  renderRows();
  recommendationText.textContent = 'Add your appliances';
  recommendationDetail.textContent = 'Your generator recommendation will appear here.';
});

document.getElementById('addBtn').addEventListener('click', ()=>{
  const nameInput = document.getElementById('customName');
  const qtyInput = document.getElementById('customQty');
  const powerInput = document.getElementById('customPower');
  const name = nameInput.value.trim();
  const qty = Number(qtyInput.value);
  const power = Number(powerInput.value);

  if(!name || !Number.isFinite(qty) || qty < 0 || !Number.isFinite(power) || power < 0){
    alert('Please enter a valid appliance name, quantity and kW value.');
    return;
  }
  appliances.push({name, power, qty});
  nameInput.value = '';
  qtyInput.value = '';
  powerInput.value = '';
  renderRows();
});

renderRows();
