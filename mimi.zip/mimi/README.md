# Mimi — Generator Recommendation System

Mimi is a responsive JavaScript web application based on the Week 4 Mini Project brief.

## Features
- Responsive desktop, tablet and mobile layout
- Appliance quantity inputs
- Automatic consumption calculation (quantity × unit consumption)
- Automatic appliance remarks:
  - Below 5kW: Low
  - 5kW to below 10kW: Medium
  - 10kW to 15kW: High
  - Above 15kW: Too high
- Generator recommendation:
  - Below 7.5kW → 7.5kW Generator
  - 7.5kW to below 10kW → 10kW Generator
  - 10kW to below 15kW → 15kW Generator
  - 15kW and above → We do not sell
- Add custom appliances
- Reset button
- No backend required

## Run
Open `index.html` in a browser.

## Files
- `index.html`
- `css/style.css`
- `js/app.js`
